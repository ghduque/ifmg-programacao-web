<?php
session_start();

// Use trim() para remover espaços
$login = trim($_POST['txtLogin']);
$password = trim($_POST['txtSenha']);

if ($login == 'Gabriel' && $password == '1234'){
    unset($_SESSION['erro']);
    $_SESSION['login'] = $login;
    header('location: pagina1.php');
    exit();
} else {
    $_SESSION['erro'] = 'Login ou senha incorretos';
    header('location: index.php');
    exit();
}
?>