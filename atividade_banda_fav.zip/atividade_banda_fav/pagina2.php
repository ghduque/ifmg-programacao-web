<?php
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['login'])) {
    header('location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Turnês e Fotos - Metallica</title>
    <link href="https://fonts.googleapis.com/css2?family=Metal+Mania&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/pagina2.css">
</head>
<body>
    <div class="container">
        <header class="header">
            <h1>Metallica - Turnês & Fotos</h1>
            <nav class="nav-menu">
                <a href="pagina1.php">Curiosidades</a>
                <a href="pagina2.php" class="active">Turnês & Fotos</a>
                <a href="logout.php" class="btn-logout">Sair</a>
            </nav>
        </header>

        <!-- Seção de Turnês -->
        <section class="tours-section">
            <h2 class="section-title">🎤 Principais Turnês</h2>
            
            <div class="tour-grid">
                <div class="tour-card">
                    <div class="tour-header">
                        <h3>M72 World Tour</h3>
                        <span class="tour-year">2023-2024</span>
                    </div>
                    <div class="tour-content">
                        <p><strong>Álbum:</strong> 72 Seasons</p>
                        <p><strong>Shows:</strong> Mais de 50 apresentações em estádios</p>
                        <p><strong>Destaque:</strong> Palco central em 360°, setlist diferente a cada noite</p>
                        <p><strong>Países:</strong> EUA, Europa, América do Sul, Ásia</p>
                    </div>
                </div>

                <div class="tour-card">
                    <div class="tour-header">
                        <h3>WorldWired Tour</h3>
                        <span class="tour-year">2016-2019</span>
                    </div>
                    <div class="tour-content">
                        <p><strong>Álbum:</strong> Hardwired... to Self-Destruct</p>
                        <p><strong>Shows:</strong> 175+ apresentações</p>
                        <p><strong>Destaque:</strong> Uma das maiores turnês da década</p>
                        <p><strong>Arrecadação:</strong> Mais de $400 milhões</p>
                    </div>
                </div>

                <div class="tour-card">
                    <div class="tour-header">
                        <h3>Death Magnetic Tour</h3>
                        <span class="tour-year">2008-2010</span>
                    </div>
                    <div class="tour-content">
                        <p><strong>Álbum:</strong> Death Magnetic</p>
                        <p><strong>Shows:</strong> 140+ apresentações</p>
                        <p><strong>Destaque:</strong> Retorno ao thrash metal clássico</p>
                        <p><strong>Especial:</strong> Shows em festivais e arenas</p>
                    </div>
                </div>

                <div class="tour-card">
                    <div class="tour-header">
                        <h3>Black Album Tour</h3>
                        <span class="tour-year">1991-1993</span>
                    </div>
                    <div class="tour-content">
                        <p><strong>Álbum:</strong> Metallica (Black Album)</p>
                        <p><strong>Shows:</strong> 300+ apresentações</p>
                        <p><strong>Destaque:</strong> Turnê que consagrou a banda mundialmente</p>
                        <p><strong>Histórico:</strong> Levou o metal aos estádios</p>
                    </div>
                </div>

                <div class="tour-card">
                    <div class="tour-header">
                        <h3>Damaged Justice Tour</h3>
                        <span class="tour-year">1988-1989</span>
                    </div>
                    <div class="tour-content">
                        <p><strong>Álbum:</strong> ...And Justice for All</p>
                        <p><strong>Shows:</strong> 240+ apresentações</p>
                        <p><strong>Destaque:</strong> Primeiro tour após a morte de Cliff Burton</p>
                        <p><strong>Marco:</strong> Consolidação com Jason Newsted no baixo</p>
                    </div>
                </div>

                <div class="tour-card">
                    <div class="tour-header">
                        <h3>Master of Puppets Tour</h3>
                        <span class="tour-year">1986</span>
                    </div>
                    <div class="tour-content">
                        <p><strong>Álbum:</strong> Master of Puppets</p>
                        <p><strong>Shows:</strong> 100+ apresentações</p>
                        <p><strong>Destaque:</strong> Último tour com Cliff Burton</p>
                        <p><strong>Tragédia:</strong> Interrompida pelo acidente fatal</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Seção de Galeria de Fotos -->
        <section class="gallery-section">
            <h2 class="section-title">📸 Galeria de Fotos</h2>

            <div class="photo-grid">
                <div class="photo-card">
                    <div class="photo-placeholder">
                        <img src="fotos/foto1.jpeg" a   lt="Metallica - Foto 1" onerror="this.src='https://via.placeholder.com/400x300/1a1a1a/8b00ff?text=Adicione+foto1.jpg'">
                    </div>
                    <div class="photo-caption">
                        <p>James Hetfield no palco</p>
                    </div>
                </div>

                <div class="photo-card">
                    <div class="photo-placeholder">
                        <img src="fotos/foto2.jpg" alt="Metallica - Foto 2" onerror="this.src='https://via.placeholder.com/400x300/1a1a1a/8b00ff?text=Adicione+foto2.jpg'">
                    </div>
                    <div class="photo-caption">
                        <p>Lars Ulrich na bateria</p>
                    </div>
                </div>

                <div class="photo-card">
                    <div class="photo-placeholder">
                        <img src="fotos/foto3.jpg" alt="Metallica - Foto 3" onerror="this.src='https://via.placeholder.com/400x300/1a1a1a/8b00ff?text=Adicione+foto3.jpg'">
                    </div>
                    <div class="photo-caption">
                        <p>Kirk Hammett com sua guitarra</p>
                    </div>
                </div>

                <div class="photo-card">
                    <div class="photo-placeholder">
                        <img src="fotos/foto4.jpeg" alt="Metallica - Foto 4" onerror="this.src='https://via.placeholder.com/400x300/1a1a1a/8b00ff?text=Adicione+foto4.jpg'">
                    </div>
                    <div class="photo-caption">
                        <p>Robert Trujillo no baixo</p>
                    </div>
                </div>

                <div class="photo-card">
                    <div class="photo-placeholder">
                        <img src="fotos/foto5.jpeg" alt="Metallica - Foto 5" onerror="this.src='https://via.placeholder.com/400x300/1a1a1a/8b00ff?text=Adicione+foto5.jpg'">
                    </div>
                    <div class="photo-caption">
                        <p>Banda completa em show</p>
                    </div>
                </div>

                <div class="photo-card">
                    <div class="photo-placeholder">
                        <img src="fotos/foto6.jpeg" alt="Metallica - Foto 6" onerror="this.src='https://via.placeholder.com/400x300/1a1a1a/8b00ff?text=Adicione+foto6.jpg'">
                    </div>
                    <div class="photo-caption">
                        <p>Público em êxtase</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Seção de Recordes -->
        <section class="records-section">
            <h2 class="section-title">🏆 Recordes e Marcos</h2>
            
            <div class="records-grid">
                <div class="record-card">
                    <div class="record-icon">🌍</div>
                    <h3>7 Continentes</h3>
                    <p>Primeira banda a tocar em todos os continentes em um ano (2013)</p>
                </div>

                <div class="record-card">
                    <div class="record-icon">💿</div>
                    <h3>125+ Milhões</h3>
                    <p>Álbuns vendidos em todo o mundo</p>
                </div>

                <div class="record-card">
                    <div class="record-icon">🎸</div>
                    <h3>3,000+ Shows</h3>
                    <p>Mais de 3 mil apresentações ao vivo desde 1981</p>
                </div>

                <div class="record-card">
                    <div class="record-icon">👥</div>
                    <h3>1.6 Milhões</h3>
                    <p>Público recorde em festival em Moscow (1991)</p>
                </div>
            </div>
        </section>

        <footer class="footer">
            <p>&copy; 2024 - Página de fã do Metallica | Bem-vindo, <?php echo $_SESSION['login']; ?>!</p>
        </footer>
    </div>

    <script>
        // Animação ao scroll
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('show');
                }
            });
        }, { threshold: 0.1 });

        document.querySelectorAll('.tour-card, .photo-card, .record-card').forEach((element) => {
            observer.observe(element);
        });
    </script>
</body>
</html>