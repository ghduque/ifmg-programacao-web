<?php
session_start();
$mensagem = 'Faça seu login no sistema';
$mostrarFormulario = true;
$logado = false;

if (isset($_SESSION['erro'])) {
    $mensagem = 'Seu login está incorreto.';
}

if (isset($_SESSION['login'])) {
    $mensagem = 'Você já está logado no sistema.';
    $mostrarFormulario = false;
    $logado = true;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Metallica Theme</title>
    <link href="https://fonts.googleapis.com/css2?family=Metal+Mania&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="login-box">
            <h2>Metallica</h2>
            <p><?php echo $mensagem; ?></p>

            <?php if (isset($_SESSION['erro'])): ?>
                <div class="erro">Login ou senha incorretos!</div>
            <?php endif; ?>

            <?php if ($mostrarFormulario && !$logado): ?>
                <form action="login.php" method="post">
                    <div class="input-group">
                        <label for="txtLogin">Login</label>
                        <input type="text" name="txtLogin" id="txtLogin" required autofocus>
                    </div>
                    <div class="input-group">
                        <label for="txtSenha">Senha</label>
                        <input type="password" name="txtSenha" id="txtSenha" required>
                    </div>
                    <button type="submit" name="btnEnviar" class="btn-submit">Entrar</button>
                </form>
            <?php endif; ?>

            <?php if ($logado): ?>
                <div class="success-message">✓ Você está logado no sistema!</div>
                <div class="btn-center">
                    <a href="logout.php" class="logout-btn">Sair do Sistema</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>