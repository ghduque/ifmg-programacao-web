<?php
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['login'])) {
    header('location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Curiosidades - Metallica</title>
    <link href="https://fonts.googleapis.com/css2?family=Metal+Mania&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/pagina1.css">
</head>
<body>
    <!-- Áudio de fundo -->
    <audio id="backgroundMusic" loop>
        <source src="musicas/enter-sandman-remastered.mp3" type="audio/mpeg">
        Seu navegador não suporta áudio.
    </audio>

    <div class="container">
        <header class="header">
            <h1>Metallica - Curiosidades</h1>
            <div class="user-info">
                <span>Bem-vindo, <?php echo $_SESSION['login']; ?>!</span>
                <a href="pagina2.php" class="btn-nav">Turnês & Fotos</a>
                <a href="logout.php" class="btn-logout">Sair</a>
            </div>
        </header>

        <!-- Controle de áudio -->
        <div class="audio-control">
            <button id="playPauseBtn" class="btn-audio">▶️ Reproduzir Música</button>
            <input type="range" id="volumeControl" min="0" max="100" value="50" class="volume-slider">
            <span id="volumeLabel">Volume: 50%</span>
        </div>

        <main class="content">
            <div class="curiosity-card">
                <h2>🎸 Formação da Banda</h2>
                <p>O Metallica foi formado em 1981 em Los Angeles por Lars Ulrich (bateria) e James Hetfield (vocal e guitarra). O nome da banda foi sugerido por um amigo de Lars, que estava escolhendo entre "Metallica" e "Metal Mania" para uma revista de heavy metal.</p>
            </div>

            <div class="curiosity-card">
                <h2>🏆 Prêmios e Conquistas</h2>
                <p>A banda ganhou 9 prêmios Grammy e é uma das bandas de metal mais bem-sucedidas comercialmente da história, tendo vendido mais de 125 milhões de álbuns em todo o mundo.</p>
            </div>

            <div class="curiosity-card">
                <h2>🎵 O Álbum Negro</h2>
                <p>O álbum "Metallica" (1991), conhecido como "Black Album" por sua capa totalmente preta, é o álbum de heavy metal mais vendido da história nos Estados Unidos, com mais de 17 milhões de cópias vendidas.</p>
            </div>

            <div class="curiosity-card">
                <h2>🌍 Todos os Continentes</h2>
                <p>Em 2013, o Metallica se tornou a primeira banda a tocar em todos os sete continentes em um único ano, incluindo um show exclusivo na Antártica para 120 fãs e cientistas!</p>
            </div>

            <div class="curiosity-card">
                <h2>🎬 Documentário "Some Kind of Monster"</h2>
                <p>O documentário de 2004 mostrou os bastidores da banda durante a gravação do álbum "St. Anger", revelando conflitos internos e a contratação de um terapeuta para ajudar a banda a se manter unida.</p>
            </div>

            <div class="curiosity-card">
                <h2>⚡ Cliff Burton</h2>
                <p>O lendário baixista Cliff Burton faleceu tragicamente em 1986 em um acidente de ônibus na Suécia. Ele é considerado um dos melhores baixistas de metal de todos os tempos e sua influência na banda foi enorme.</p>
            </div>

            <div class="curiosity-card">
                <h2>🎸 Logo Icônico</h2>
                <p>O famoso logo do Metallica foi desenhado por James Hetfield em 1980. A tipografia angular e agressiva se tornou uma das marcas visuais mais reconhecidas do rock mundial.</p>
            </div>

            <div class="curiosity-card">
                <h2>🎼 "Master of Puppets"</h2>
                <p>Em 2016, "Master of Puppets" se tornou a primeira música de metal a ser incluída no National Recording Registry da Biblioteca do Congresso dos EUA por ser "cultural, histórica ou esteticamente significativa".</p>
            </div>

            <div class="curiosity-card featured">
                <h2>💫 "Enter Sandman" - Minha Favorita!</h2>
                <p>"Enter Sandman" é o primeiro single do Black Album (1991) e se tornou a música mais conhecida do Metallica. O riff icônico foi criado por Kirk Hammett e a letra fala sobre pesadelos infantis. A música alcançou o top 20 da Billboard Hot 100 e seu videoclipe se tornou um dos mais tocados da MTV nos anos 90. É a música de entrada dos jogadores do New York Yankees no Yankee Stadium! Esta faixa representa perfeitamente a transição do Metallica para um som mais acessível sem perder a essência do heavy metal.</p>
            </div>
        </main>

        <footer class="footer">
            <p>&copy; 2024 - Página de fã do Metallica</p>
        </footer>
    </div>

    <script>
        // Controle de áudio
        const audio = document.getElementById('backgroundMusic');
        const playPauseBtn = document.getElementById('playPauseBtn');
        const volumeControl = document.getElementById('volumeControl');
        const volumeLabel = document.getElementById('volumeLabel');

        // Define volume inicial
        audio.volume = 0.5;

        // Play/Pause
        playPauseBtn.addEventListener('click', function() {
            if (audio.paused) {
                audio.play();
                playPauseBtn.textContent = '⏸️ Pausar Música';
                playPauseBtn.classList.add('playing');
            } else {
                audio.pause();
                playPauseBtn.textContent = '▶️ Reproduzir Música';
                playPauseBtn.classList.remove('playing');
            }
        });

        // Controle de volume
        volumeControl.addEventListener('input', function() {
            const volume = this.value / 100;
            audio.volume = volume;
            volumeLabel.textContent = `Volume: ${this.value}%`;
        });

        // Animação nas cards ao scroll
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('show');
                }
            });
        });

        document.querySelectorAll('.curiosity-card').forEach((card) => {
            observer.observe(card);
        });
    </script>
</body>
</html>