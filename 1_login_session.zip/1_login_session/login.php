<?php
session_start();
$mensagem = 'Faça seu login no sistema';
$mostrarFormulario = true;
$logado = false;

if (isset($_SESSION['erro'])) {
    $mensagem = 'Seu login está incorreto.';
}

if (isset($_SESSION['login'])) {
    $mensagem = 'Você já está logado no sistema.';
    $mostrarFormulario = false;
    $logado = true;
}
?>
