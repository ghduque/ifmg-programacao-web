<?php
session_start(); 
$mensagem = 'Fa&ccedil;a seu login no sistema';
$mensagem .= '<br>
    <form action="login.php" method="post">
       Login: <input type="text" name="txtLogin"><br> 
       Senha: <input type="password" name="txtSenha"><br>
       <input type="submit" name="btnEnviar"> 
    </form>';

if (isset($_SESSION['erro']))
{
    $mensagem = 'Seu login est&aacute; incorreto.';
    $mensagem .= '<br>
     <form action="login.php" method="post">
       Login: <input type="text" name = "txtLogin"><br> 
       Senha: <input type="password" name = "txtSenha"><br>
       <input type = "submit" name="btnEnviar"> 
    </form>';
}    


if (isset($_SESSION['login']))
{
    $mensagem = 'Voc&ecirc; j&aacute; est&aacute logado no sistema.';
    $mensagem .= '</br></br>
     <a href ="pagina1.php">P&aaute;gina 1<\a>
     <a href ="pagina2.php">P&aaute;gina 2<\a>
     <a href ="pagina3.php">P&aaute;gina 3<\a>
     <a href ="logout.php">SAIR DO SISTEMA<\a><\br><\br>


    </form>';
}   

?>

<html>
<head>
    </head>
    <body>
        <?php echo $mensagem; ?>
    </body>
</html>
