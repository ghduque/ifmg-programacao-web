<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado do Amor</title>
    <link rel="stylesheet" type="text/css" href="css/estilodoamor.css">
</head>
<body>
    <?php
    $nome1 = strtoupper(trim($_POST['txtName1']));
    $nome2 = strtoupper(trim($_POST['txtName2']));

    // Lista simples de combinações especiais
    $especiais = [
        'GABRIEL-LAVINIA' => 100,
        'GABRIEL-CÉSAR' => 100,
        'GABRIEL-CESAR' => 100,
        'GABRIEL FELIPE-CESAR' => 100,
        'GABRIEL FELIPE-CÉSAR' => 100,
        'JOÃO-MARIA' => 85,
        'JOAO-MARIA' => 85,
        'JOAO BRUNO-RICARDO' => 100, 
        'GABRIEL-JULIA' => 0, 
    ];

    // Cria as duas chaves possíveis (ordem não importa)
    $chave1 = $nome1 . '-' . $nome2;
    $chave2 = $nome2 . '-' . $nome1;

    // Verifica se existe combinação especial
    if (isset($especiais[$chave1])) {
        $porcentagem = $especiais[$chave1];
    } elseif (isset($especiais[$chave2])) {
        $porcentagem = $especiais[$chave2];
    } else {
        // Cálculo normal
        $valores = [
            'A'=> 10, 'B'=> 10, 'C'=> 10, 'D'=> 10, 'E'=> 10,
            'F'=> 10, 'G'=> 10, 'H'=> 10, 'I'=> 10, 'J'=> 10,
            'K'=> 10, 'L'=> 10, 'M'=> 10, 'N'=> 10, 'O'=> 10,
            'P'=> 10, 'Q'=> 10, 'R'=> 10, 'S'=> 10, 'T'=> 10,
            'U'=> 10, 'V'=> 10, 'W'=> 10, 'X'=> 10, 'Y'=> 10,
            'Z'=> 10
        ];

        $soma = 0;

        for ($i = 0; $i < strlen($nome1); $i++) {
            $letra = $nome1[$i];
            if (isset($valores[$letra])) {
                $soma += $valores[$letra];
            }
        }

        for ($i = 0; $i < strlen($nome2); $i++) {
            $letra = $nome2[$i];
            if (isset($valores[$letra])) {
                $soma += $valores[$letra];
            }
        }

        $porcentagem = abs($soma) % 101;
    }

    // Define se é caso especial (para mostrar animação de corações)
    $casoEspecial = false;
    if (($nome1 == 'GABRIEL FELIPE' && $nome2 == 'CESAR') || 
        ($nome1 == 'CESAR' && $nome2 == 'GABRIEL FELIPE') ||
        ($nome1 == 'GABRIEL' && ($nome2 == 'CÉSAR' || $nome2 == 'CESAR')) || 
        (($nome1 == 'CÉSAR' || $nome1 == 'CESAR') && $nome2 == 'GABRIEL') ||
        ($nome1 == 'GABRIEL' && $nome2 == 'LAVINIA') || 
        ($nome1 == 'LAVINIA' && $nome2 == 'GABRIEL') ||
        $nome1 == 'JULIA' || $nome2 == 'JULIA') {
        $casoEspecial = true;
    }

    // Determina a mensagem
    $mensagem = '';
    if (($nome1 == 'GABRIEL FELIPE' && $nome2 == 'CESAR') || ($nome1 == 'CESAR' && $nome2 == 'GABRIEL FELIPE')) {
        $mensagem = "Vocês dois estão adiando o inevitável e deveriam se assumir logo! 🌈";
    } elseif (($nome1 == 'GABRIEL' && ($nome2 == 'CÉSAR' || $nome2 == 'CESAR')) || 
              (($nome1 == 'CÉSAR' || $nome1 == 'CESAR') && $nome2 == 'GABRIEL')) {
        $mensagem = "Vocês dois estão adiando o inevitável e deveriam se assumir logo! 🌈";
    } elseif (($nome1 == 'GABRIEL' && $nome2 == 'LAVINIA') || ($nome1 == 'LAVINIA' && $nome2 == 'GABRIEL')) {
        $mensagem = "Vocês dois estão enrolando demais! São ótimos juntos e devem parar de enrolar! 💕";
    } elseif ($nome1 == 'JULIA' || $nome2 == 'JULIA') {
        $mensagem = "CORRE!!! 🚨 Toda Julia é furada, é golpe! Fuja enquanto é tempo! 🏃‍♂️💨";
    } else {
        // MENSAGENS POR PORCENTAGEM
        if ($porcentagem == 100) {
            $mensagem = "Case com ele(a) agora!!!! 💍💕";
        } elseif ($porcentagem >= 80 && $porcentagem < 100) {
            $mensagem = "Vai fundo, grandes chances de dar certo! 🎯❤️";
        } elseif ($porcentagem >= 50 && $porcentagem <= 70) {
            $mensagem = "Chame-o(a) para sair e se conhecerem, algo bom pode sair daí! 😊☕";
        } elseif ($porcentagem >= 40 && $porcentagem < 50) {
            $mensagem = "Talvez dê certo... vale a tentativa! 🤔";
        } elseif ($porcentagem >= 10 && $porcentagem < 40) {
            $mensagem = "Chance baixa de dar certo, tente a sorte! 🎲";
        } else {
            $mensagem = "Melhor nem tentar... 😬";
        }
    }
    ?>

    <!-- Corações de fundo -->
    <div class="background-hearts">
        <div class="heart-bg">💗</div>
        <div class="heart-bg">💕</div>
        <div class="heart-bg">💖</div>
        <div class="heart-bg">💝</div>
        <div class="heart-bg">💘</div>
        <div class="heart-bg">💓</div>
        <div class="heart-bg">💞</div>
    </div>

    <?php if ($casoEspecial): ?>
    <!-- Corações flutuando/estourando para casos especiais -->
    <div class="special-hearts">
        <div class="heart-float">💕</div>
        <div class="heart-float">💖</div>
        <div class="heart-float">💗</div>
        <div class="heart-float">💝</div>
        <div class="heart-float">💘</div>
        <div class="heart-float">💓</div>
        <div class="heart-float">💞</div>
        <div class="heart-float">💕</div>
        <div class="heart-float">💖</div>
        <div class="heart-float">💗</div>
        <div class="heart-float">💝</div>
        <div class="heart-float">💘</div>
    </div>
    <?php endif; ?>

    <!-- Container de resultado -->
    <div class="result-container">
        <h1>💘 Resultado do Amor 💘</h1>
        
        <p><strong><?php echo $_POST['txtName1']; ?></strong> e <strong><?php echo $_POST['txtName2']; ?></strong></p>
        
        <div class="percentage"><?php echo $porcentagem; ?>%</div>
        
        <div class="message"><?php echo $mensagem; ?></div>
        
        <a href="javascript:history.back()" class="back-button">← Voltar</a>
    </div>

</body>
</html>