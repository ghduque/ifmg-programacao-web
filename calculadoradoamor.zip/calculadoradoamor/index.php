<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora do Amor</title>
    <link rel="stylesheet" type="text/css" href="css/estilodoamor.css">
</head>
<body>
    <!-- Corações de fundo -->
    <div class="background-hearts">
        <div class="heart-bg">💗</div>
        <div class="heart-bg">💕</div>
        <div class="heart-bg">💖</div>
        <div class="heart-bg">💝</div>
        <div class="heart-bg">💘</div>
        <div class="heart-bg">💓</div>
        <div class="heart-bg">💞</div>
    </div>

    <!-- Calculadora -->
    <div class="calculator-container">
        <h1>💘 Calculadora do Amor 💘</h1>
        <form action="calcula.php" method="post">
            <table>
                <tr>
                    <td>Primeiro Nome:</td>
                    <td>
                        <input
                            type="text"
                            name="txtName1"
                            id="txtName1"
                            placeholder="Digite o primeiro nome"
                            required/>
                    </td>
                </tr>
                <tr>
                    <td>Segundo Nome:</td>
                    <td>
                        <input
                            type="text"
                            name="txtName2"
                            id="txtName2"
                            placeholder="Digite o segundo nome"
                            required/>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input
                            type="submit"
                            value="💕 Calcular Amor 💕"
                            name="btnEnviar"
                            id="btnEnviar" />
                    </td>
                </tr>
            </table>
        </form>
    </div>

    <!-- ADICIONE SEUS CUPIDOS AQUI (opcional) -->
    <!-- Exemplo: 
    <img src="images/cupido.gif" style="position: fixed; bottom: 20px; left: 20px; width: 150px; z-index: 100;">
    <img src="images/cupido.gif" style="position: fixed; top: 20px; right: 20px; width: 150px; z-index: 100; transform: scaleX(-1);">
    -->

</body>
</html>