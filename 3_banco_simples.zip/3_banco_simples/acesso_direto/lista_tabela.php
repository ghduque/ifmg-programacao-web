<?php
//comando para exibir erros durante a execução do código PHP
ini_set('display_errors', 1);
//comando para exibir erros antes da execução do código 
ini_set('display_startup_errors', 1);
//comando para listar os erros 
error_reporting(E_ALL); 

//executando conexão com o banco de dados
$conexao = mysqli_connect('localhost','root','','bd_teste');

//verificando se a conexão foi bem sucedida
if (!$conexao) {
    die('Erro de conexão: ' . mysqli_conecct_error()); 
} 

//executar a SQL para consulta de dados
$sql = 'SELECT * FROM tb_pessoa;'; 
$tabela = mysqli_query($conexao, $sql) or die ('Erro na consulta: ' . mysqli_error($conexao)); 

//verificar se existem registros 
if (mysqli_num_rows($tabela) > 0) {
    echo 'Existem ' . mysqli_num_rows($tabela) . ' registros encontrados.<br><br>';
    
    //exibir os dados em forma de tabela HTML
    echo '<table border="1px">'; 
    echo '<tr><th>ID</th><th>NOME</th><th>IDADE</th><th>EXCLUIR</th></tr>';
    while ($linha = mysqli_fetch_row($tabela)) {
        echo '<tr>';
        echo '<td>' . $linha[0] . '</td>';
        echo '<td>' . $linha[1] . '</td>';
        echo '<td>' . $linha[2] . '</td>';
        echo '<td><img src="excluir.jpeg" /></td>';
        echo '</tr>';
    }

    echo '</table>';

} else {
    echo 'Nenhum registro encontrado.';
}

mysqli_close($conexao);
echo '<a href="menu.php">Voltar ao menu</a>';
?>