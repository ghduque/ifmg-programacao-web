<?php
//comando para exibir erros durante a execução do código PHP
ini_set('display_errors', 1);
//comando para exibir erros antes da execução do código 
ini_set('display_startup_errors', 1);
//comando para listar os erros 
error_reporting(E_ALL); 

//executando conexão com o banco de dados
$conexao = mysqli_connect('localhost','root','','bd_teste');

//verificando se a conexão foi bem sucedida
if (!$conexao) {
    die('Erro de conexão: ' . mysqli_conecct_error()); 
} 

//criar a SQL para inserção de dados 
$sql = 'INSERT INTO tb_pessoa (nome,idade) 
        VALUES ("César Menotti e Fabiano", 35);'; 

//executar a consulta SQL 
$resultado = mysqli_query($conexao, $sql); 

//verificando o retorno
if ($resultado) {
    echo 'Dados inseridos com sucesso!';
} else {
    echo 'Erro ao inserir dados: ' . mysqli_error($conexao);
}

mysqli_close($conexao);

echo '<a href="menu.php">Voltar ao menu</a>';

?>