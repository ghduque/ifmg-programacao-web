<html>
    <head></head>
    <body>
        <div style="text-align: center;">
        <h1>O QUE VOCÊ DESEJA FAZER?</h1>
        <br>
        <a href="inserir.php">Inserir um novo dado no banco de dados</a>
        <br>
        <a href="consultar.php">Executar uma consulta no banco de dados</a>
        <br>    
        <a href="lista_tabela.php">Exibir consulta na forma de tabela</a>    
    </div>
    </body>
</html>