<?php
//classe responsável pela conexão com o banco de dados
//padrao SINGLETON
class clsConexao {
  //variaveis privadas
  private static $instancia = null;
  private $conexao; 
  //método construtor
  private function __construct() {
    $this->conexao = new mysqli('localhost','root','','db_teste');
    if ($this->conexao->connect_error) {
        die("Conexão falhou: " . $this->conexao->connect_error);
  }
 }

//método que retorna a instância da conexão com o banco de dados
public static function getInstancia() {
    if (!self::$instancia) {
        self::$instancia = new clsConexao();
    }
    return self::$instancia;
    }

private function detectarTipos($parametros) {
    $tipos = '';
    foreach ($parametros as $parametro) {
        if (is_int($parametro)) {
            $tipos .= 'i'; //inteiro
        } elseif (is_double($parametro) || is_float($parametro)) {
            $tipos .= 'd'; //double ou float  
        } elseif (is_string($parametro)) {
            $tipos .= 's'; //string
        } else {
            $tipos .= 'b'; //dados bináros
        }
    }
    return $tipos;
}


public function execultarConsulta($sql,$parametros = []) {
    $comando = $this->conexao->prepare($sql);
    if (!empty($parametros)) {
        $tipos = $this->detectarTipos($parametros);
        $comando->bind_param($tipos, ...$parametros);
    }
    $comando->execute();
    return $comando; 
  }
}
?>