<?php
session_start();

// O formulário (index.php) envia seus dados para cá (crop.php)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // 1. Salva todos os dados do formulário (nome, cpf, etc.) na sessão
    $_SESSION['form_data'] = $_POST;

    // 2. Verifica se uma NOVA imagem recortada foi enviada (Base64)
    if (isset($_POST['croppedImageData']) && !empty($_POST['croppedImageData'])) {
        
        $imageData = $_POST['croppedImageData'];

        // Remove o cabeçalho "data:image/jpeg;base64,"
        list($type, $imageData) = explode(';', $imageData);
        list(, $imageData)      = explode(',', $imageData);
        $imageData = base64_decode($imageData);

        // Define o diretório de uploads
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true); // Cria a pasta se não existir
        }

        // Gera um nome de arquivo único
        $newFileName = $uploadDir . uniqid('foto_') . '.jpg';

        // Salva o arquivo de imagem no servidor
        if (file_put_contents($newFileName, $imageData)) {
            // Salva o CAMINHO da imagem na sessão
            $_SESSION['cropped_photo_path'] = $newFileName;
        } else {
            // Lidar com erro ao salvar
            echo "Erro ao salvar a imagem recortada.";
            exit;
        }

    } elseif (isset($_POST['existing_photo_path']) && !empty($_POST['existing_photo_path'])) {
        // 3. Se nenhuma imagem nova foi enviada, mantém a foto existente (que já estava na sessão)
        $_SESSION['cropped_photo_path'] = $_POST['existing_photo_path'];
    }

    // 4. Redireciona para a página de confirmação
    header('Location: confirm.php');
    exit();

} else {
    // Se alguém acessar crop.php diretamente, redireciona para o início
    header('Location: index.php');
    exit();
}
?>