document.addEventListener('DOMContentLoaded', function() {
    
    // --- Máscara de CPF (sem alterações) ---
    const cpfInput = document.getElementById('cpf');
    if (cpfInput) {
        cpfInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 11) {
                value = value.substring(0, 11);
            }
            if (value.length > 9) {
                value = value.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
            } else if (value.length > 6) {
                value = value.replace(/(\d{3})(\d{3})(\d{3})/, '$1.$2.$3');
            } else if (value.length > 3) {
                value = value.replace(/(\d{3})(\d{3})/, '$1.$2');
            }
            e.target.value = value;
        });
    }

    // --- Lógica de Upload e Recorte ---
    const foto3x4Input = document.getElementById('foto3x4');
    const uploadBox = document.getElementById('uploadBox');
    const uploadPlaceholder = document.getElementById('uploadPlaceholder');
    const finalPreview = document.getElementById('finalPreview');
    
    const cropModal = document.getElementById('cropModal');
    const imageToCrop = document.getElementById('imageToCrop');
    const cropButton = document.getElementById('cropButton');
    const croppedImageDataInput = document.getElementById('croppedImageData');
    
    let cropper;

    // 1. Quando o usuário clica na caixa de upload
    uploadBox.addEventListener('click', () => {
        foto3x4Input.click();
    });

    // 2. Quando o usuário seleciona um arquivo
    foto3x4Input.addEventListener('change', function(e) {
        if (e.target.files && e.target.files[0]) {
            const reader = new FileReader();
            
            reader.onload = function(event) {
                // Coloca a imagem no modal e o exibe
                imageToCrop.src = event.target.result;
                cropModal.style.display = 'block';

                // Destrói o cropper antigo, se existir
                if (cropper) {
                    cropper.destroy();
                }

                // Inicia o Cropper.js na imagem
                cropper = new Cropper(imageToCrop, {
                    aspectRatio: 3 / 4, // Proporção 3x4
                    viewMode: 1,
                    background: false,
                    autoCropArea: 0.8
                });
            };
            
            reader.readAsDataURL(e.target.files[0]);
        }
    });

    // 3. Quando o usuário clica em "Recortar e Salvar" no modal
    cropButton.addEventListener('click', function() {
        if (!cropper) {
            return;
        }

        // Pega a imagem recortada (em Base64)
        const croppedCanvas = cropper.getCroppedCanvas({
            width: 300,  // Define um tamanho fixo (300x400)
            height: 400
        });
        
        const croppedBase64 = croppedCanvas.toDataURL('image/jpeg', 0.9); // Converte para JPEG

        // Coloca a imagem recortada no campo escondido do formulário
        croppedImageDataInput.value = croppedBase64;

        // Mostra a prévia na página principal
        finalPreview.src = croppedBase64;
        finalPreview.style.display = 'block';
        uploadPlaceholder.style.display = 'none'; // Esconde o placeholder

        // Esconde o modal
        cropModal.style.display = 'none';
    });

    // 4. (Opcional) Se o usuário fechar o modal (ex: clicando fora), resetamos o input
    window.onclick = function(event) {
        if (event.target == cropModal) {
            cropModal.style.display = "none";
            foto3x4Input.value = ""; // Limpa o input de arquivo
            if (cropper) {
                cropper.destroy();
            }
        }
    }
});