<?php
session_start();

// --- PASSO 1: PROCESSAR O ENVIO (POST) ---
// Se a página for carregada via POST, processe os dados e redirecione.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // 1. Salva os dados de texto do formulário
    $_SESSION['form_data'] = $_POST;
    
    // Limpa qualquer erro de upload anterior
    unset($_SESSION['upload_error']);
    unset($_SESSION['cropped_photo_path']); // Limpa foto antiga

    // 2. Processa a imagem cortada (Base64)
    if (isset($_POST['croppedImageData']) && !empty($_POST['croppedImageData'])) {
        $imageData = $_POST['croppedImageData'];
        
        // Limpa o prefixo "data:image/..."
        $imageData = str_replace(['data:image/jpeg;base64,', 'data:image/png;base64,'], '', $imageData);
        $imageData = str_replace(' ', '+', $imageData);
        $decodedImage = base64_decode($imageData);

        if ($decodedImage) {
            // __DIR__ é o caminho absoluto da pasta do seu projeto (ex: /opt/lampp/htdocs/...)
            $uploadDir = __DIR__ . '/uploads/'; // Caminho absoluto do sistema
            $webDir = 'uploads/'; // Caminho relativo da web (para o HTML)
            
            if (!is_dir($uploadDir)) {
                // Tenta criar o diretório se não existir (já deve estar ok)
                mkdir($uploadDir, 0777, true);
            }
            
            $filename = uniqid('foto_') . '.jpeg';
            $systemFilePath = $uploadDir . $filename; // Caminho para salvar no disco
            $webFilePath = $webDir . $filename; // Caminho para salvar na sessão (para <img src>)

            // Tenta salvar o arquivo no caminho absoluto do sistema
            if (file_put_contents($systemFilePath, $decodedImage)) {
                // Sucesso! Salva o caminho da WEB na sessão
                $_SESSION['cropped_photo_path'] = $webFilePath;
            } else {
                // Falha ao salvar (mesmo com permissões, algo deu errado)
                $_SESSION['upload_error'] = "Erro fatal: Não foi possível salvar a imagem. O servidor falhou ao escrever o arquivo.";
            }
        } else {
            // Falha ao decodificar
            $_SESSION['upload_error'] = "Erro: Dados da imagem inválidos ou corrompidos.";
        }
    } elseif (isset($_POST['existing_photo_path']) && !empty($_POST['existing_photo_path'])) {
        // Mantém a foto existente se nenhuma nova foi enviada
        $_SESSION['cropped_photo_path'] = $_POST['existing_photo_path'];
    }

    // 3. Redireciona para a mesma página (via GET) para exibir os dados
    // Esta é a parte mais importante da correção.
    header('Location: confirm.php');
    exit();
}

// --- PASSO 2: EXIBIR A PÁGINA (VIA GET) ---

// Se chegamos aqui (via GET) e não há dados na sessão, volta ao início
if (!isset($_SESSION['form_data'])) {
    header('Location: index.php');
    exit();
}

// Pega os dados da sessão para exibir
$formData = $_SESSION['form_data'];
$photoPath = $_SESSION['cropped_photo_path'] ?? null; // Caminho da web (ex: 'uploads/foto.jpeg')

// Verifica se houve um erro de upload na etapa POST
$uploadError = null;
if (isset($_SESSION['upload_error'])) {
    $uploadError = $_SESSION['upload_error'];
    unset($_SESSION['upload_error']); // Limpa o erro para não mostrar de novo
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirme Seus Dados</title>
    <link rel="stylesheet" href="css/style.css">
    
    <style>
        .carteirinha-photo {
            width: 90px; height: 120px; border: 1px solid #ddd;
            border-radius: 5px; overflow: hidden; background-color: #f0f0f0;
            display: flex; align-items: center; justify-content: center;
        }
        .carteirinha-photo img {
            width: 100%; height: 100%; object-fit: cover;
        }
        .error-message {
            background-color: #ffebee; color: #c62828;
            padding: 15px; border-radius: 8px;
            margin-bottom: 20px; text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Confirme seus dados</h1>
        </div>

        <?php if ($uploadError): ?>
            <div class="error-message">
                <?php echo $uploadError; ?>
            </div>
        <?php endif; ?>

        <div class="confirmation-details">
            <div class="detail-item">
                <label>Nome</label>
                <p><?php echo htmlspecialchars($formData['nome']); ?></p>
            </div>
            <div class="detail-item">
                <label>Data de Nascimento</label>
                <p><?php echo date('d/m/Y', strtotime(htmlspecialchars($formData['dataNascimento']))); ?></p>
            </div>
            <div class="detail-item">
                <label>CPF</label>
                <p><?php echo htmlspecialchars($formData['cpf']); ?></p>
            </div>
            <div class="detail-item">
                <label>Matrícula</label>
                <p><?php echo htmlspecialchars($formData['matricula']); ?></p>
            </div>
            <div class="detail-item full-width">
                <label>Curso</label>
                <p><?php echo htmlspecialchars($formData['curso']); ?></p>
            </div>
            
            <div class="detail-item full-width">
                <label>Foto 3x4</label>
                <div class="carteirinha-photo">
                    <?php
                    // Verifica se $photoPath não é nulo E se o arquivo existe no disco
                    if ($photoPath && file_exists(__DIR__ . '/' . $photoPath)): 
                    ?>
                        <img src="<?php echo htmlspecialchars($photoPath); ?>" alt="Foto 3x4">
                    <?php else: ?>
                        <p style="padding: 5px; font-size: 0.9em;">Foto não disponível</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="confirmation-actions">
            <form action="index.php" method="GET">
                <button type="submit" class="btn-secondary">Editar Dados</button>
            </form>
            <form action="carteirinha.php" method="POST">
                <button type="submit" class="btn-primary">Gerar Carteirinha</button>
            </form>
        </div>
    </div>
</body>
</html>