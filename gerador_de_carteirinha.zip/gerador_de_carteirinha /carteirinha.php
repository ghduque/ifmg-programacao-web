<?php
session_start();

// Redirect to index if no form data is found in session
if (!isset($_SESSION['form_data'])) {
    header('Location: index.php');
    exit();
}

$formData = $_SESSION['form_data'];
$photoPath = $_SESSION['cropped_photo_path'] ?? 'placeholder-photo.png'; // Placeholder if no photo
$validade = date('d/m/Y', strtotime('+4 years')); // Example: Valid for 4 years from now
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sua Carteirinha Estudantil</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1 style="text-align: center; color: #4CAF50;">Sua Carteirinha Estudantil</h1>
        <p style="text-align: center; color: #666; margin-bottom: 30px;">Carteirinha gerada com sucesso!</p>

        <div class="carteirinha-card">
            <div class="carteirinha-header">
                <div class="logo">
                    <div></div><div></div><div></div><div></div> </div>
                <div class="carteirinha-header-text">
                    <p style="font-weight: bold;">INSTITUTO FEDERAL</p>
                    <p class="campus">Minas Gerais</p>
                    <p class="campus">Campus Bambuí</p>
                </div>
            </div>
            <div class="carteirinha-body">
                <div class="carteirinha-photo">
                    <?php if (file_exists($photoPath)): ?>
                        <img src="<?php echo htmlspecialchars($photoPath); ?>" alt="Foto 3x4">
                    <?php else: ?>
                        <p style="color: #777; font-size: 0.8em;">Foto</p>
                    <?php endif; ?>
                </div>
                <div class="carteirinha-details-content">
                    <p><strong><?php echo htmlspecialchars($formData['nome']); ?></strong></p>
                    <p>Data de nascimento: <?php echo date('d/m/Y', strtotime(htmlspecialchars($formData['dataNascimento']))); ?></p>
                    <p>RG: 00000000</p> <p>CPF: <?php echo htmlspecialchars($formData['cpf']); ?></p>
                    <p><strong><?php echo htmlspecialchars($formData['curso']); ?></strong></p>
                    <p>Integral</p>
                    <p>Matrícula: <?php echo htmlspecialchars($formData['matricula']); ?></p>
                    <p class="carteirinha-validade">Validade: <?php echo htmlspecialchars($validade); ?></p>
                </div>
                <div class="barcode-visual">
                    <div class="bar-segment"></div><div class="bar-segment"></div><div class="bar-segment"></div>
                    <div class="bar-segment"></div><div class="bar-segment"></div><div class="bar-segment"></div>
                    <div class="bar-segment"></div><div class="bar-segment"></div><div class="bar-segment"></div>
                    <div class="bar-segment"></div><div class="bar-segment"></div><div class="bar-segment"></div>
                    <div class="bar-segment"></div><div class="bar-segment"></div><div class="bar-segment"></div>
                    <div class="bar-segment"></div><div class="bar-segment"></div><div class="bar-segment"></div>
                    <div class="bar-segment"></div><div class="bar-segment"></div><div class="bar-segment"></div>
                    <div class="bar-segment"></div><div class="bar-segment"></div><div class="bar-segment"></div>
                    <div class="bar-segment"></div><div class="bar-segment"></div><div class="bar-segment"></div>
                    <div class="bar-segment"></div><div class="bar-segment"></div><div class="bar-segment"></div>
                    <div class="bar-segment"></div><div class="bar-segment"></div><div class="bar-segment"></div>
                    <div class="bar-segment"></div><div class="bar-segment"></div><div class="bar-segment"></div>
                    <div class="bar-segment"></div><div class="bar-segment"></div><div class="bar-segment"></div>
                    <div class="bar-segment"></div><div class="bar-segment"></div><div class="bar-segment"></div>
                    <div class="bar-segment"></div><div class="bar-segment"></div><div class="bar-segment"></div>
                    <div class="bar-segment"></div><div class="bar-segment"></div><div class="bar-segment"></div>
                    <div class="bar-segment"></div><div class="bar-segment"></div><div class="bar-segment"></div>
                    <div class="bar-segment"></div><div class="bar-segment"></div><div class="bar-segment"></div>
                    <div class="bar-segment"></div><div class="bar-segment"></div><div class="bar-segment"></div>
                    <div class="bar-segment"></div><div class="bar-segment"></div><div class="bar-segment"></div>
                </div>
            </div>
        </div>

        <div class="carteirinha-actions">
            <form action="index.php" method="GET">
                <button type="submit" class="btn-secondary">Voltar ao Início</button>
            </form>
            <button type="button" class="btn-primary" onclick="window.print()">Imprimir Carteirinha</button>
        </div>
    </div>
</body>
</html>