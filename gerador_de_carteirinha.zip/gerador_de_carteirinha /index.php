<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carteirinha Estudantil IFMG - Formulário</title>
    <link rel="stylesheet" href="css/style.css">
    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.1/cropper.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="logo">
            <div></div><div></div><div></div><div></div></div>
            <h1>Carteirinha Estudantil IFMG</h1>
        </div>
        <form action="confirm.php" method="POST" enctype="multipart/form-data" id="studentForm">
            <div class="form-group">
                <label for="nome">Nome Completo</label>
                <input type="text" id="nome" name="nome" placeholder="Seu nome completo" required value="<?php echo $_SESSION['form_data']['nome'] ?? ''; ?>">
            </div>
            <div class="form-group">
                <label for="dataNascimento">Data de Nascimento</label>
                <input type="date" id="dataNascimento" name="dataNascimento" required value="<?php echo $_SESSION['form_data']['dataNascimento'] ?? ''; ?>">
            </div>
            <div class="form-group">
                <label for="cpf">CPF</label>
                <input type="text" id="cpf" name="cpf" placeholder="000.000.000-00" pattern="\d{3}\.\d{3}\.\d{3}-\d{2}" required value="<?php echo $_SESSION['form_data']['cpf'] ?? ''; ?>">
                <small>Formato: 000.000.000-00</small>
            </div>
            <div class="form-group">
                <label for="curso">Curso</label>
                <select id="curso" name="curso" required>
                    <option value="">Selecione seu curso</option>
                    <?php
                    $courses = [
                        "Engenharia de Computação", "Engenharia de Produção", "Engenharia de Alimentos", "Física",
                        "Agronomia", "Zootecnia", "Medicina Veterinária", "Técnico em Informática",
                        "Técnico em Agropecuária", "Técnico em Agroindústria", "Técnico em Administração",
                        "Administração", "Licenciatura em Educação Física"
                    ];
                    $selectedCourse = $_SESSION['form_data']['curso'] ?? '';
                    foreach ($courses as $course) {
                        $selected = ($course == $selectedCourse) ? 'selected' : '';
                        echo "<option value=\"$course\" $selected>$course</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="matricula">Matrícula</label>
                <input type="text" id="matricula" name="matricula" placeholder="Apenas números" pattern="[0-9]*" required value="<?php echo $_SESSION['form_data']['matricula'] ?? ''; ?>">
            </div>
            
            <div class="form-group">
                <label for="foto3x4">Foto 3x4</label>
                <div class="upload-box" id="uploadBox">
                    
                    <input type="file" id="foto3x4" name="foto3x4_original" accept="image/*">
                    
                    <div class="upload-placeholder" id="uploadPlaceholder">
                        <img src="camera-icon.png" alt="Câmera" width="50"> <p>Clique para fazer upload</p>
                    </div>

                    <img id="finalPreview" alt="Pré-visualização da Foto" style="display: none; width: 100%; max-height: 200px; object-fit: cover; border-radius: 8px;">

                    <?php if (isset($_SESSION['cropped_photo_path'])): ?>
                        <img src="<?php echo $_SESSION['cropped_photo_path']; ?>" alt="Foto Carregada" class="uploaded-photo-preview">
                        <input type="hidden" name="existing_photo_path" value="<?php echo $_SESSION['cropped_photo_path']; ?>">
                    <?php endif; ?>
                </div>
            </div>
            <input type="hidden" name="croppedImageData" id="croppedImageData">

            <button type="submit" class="btn-primary">Avançar Para Confirmação</button>
        </form>
    </div>

    <div id="cropModal" class="modal">
        <div class="modal-content">
            <h2>Recortar Foto 3x4</h2>
            <p>Ajuste a área de corte para o formato 3x4.</p>
            <div class="img-container">
                <img id="imageToCrop" alt="Imagem para recortar">
            </div>
            <button type="button" id="cropButton" class="btn-primary">Recortar e Salvar</button>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.1/cropper.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>