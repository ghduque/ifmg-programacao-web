document.addEventListener('DOMContentLoaded', () => {
    const nyanBtn = document.getElementById('nyanBtn');
    let posX = 0, posY = 0;
    let targetX = 0, targetY = 0;

    // Atualiza a posição alvo com base no movimento do mouse
    document.addEventListener('mousemove', (e) => {
        targetX = e.clientX - nyanBtn.offsetWidth / 2;
        targetY = e.clientY - nyanBtn.offsetHeight / 2;
    });

    // Animação suave para seguir o mouse
    function move() {
        posX += (targetX - posX) * 0.04; // fator de suavização
        posY += (targetY - posY) * 0.04;
        nyanBtn.style.left = posX + `px`;
        nyanBtn.style.top = posY + `px`;
        requestAnimationFrame(move);
    }
    requestAnimationFrame(move);

    // Função global para ser chamada pelo onclick do HTML
    window.mensagem = function () {
        alert("EU SOU O BATMAN! 🦇");
    };
});
