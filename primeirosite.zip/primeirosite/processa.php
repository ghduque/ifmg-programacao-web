<?php
$nome = htmlspecialchars($_GET['txtNome'] ?? '', ENT_QUOTES, 'UTF-8');
echo "O nome digitado foi: $nome";
?>
