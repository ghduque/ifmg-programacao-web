function atualizaOutIdade() {
  document.querySelector('output#txtIdade').textContent = document.getElementById('txtIdade').value;
}

function atualizaOutSatisfacao() {
  document.querySelector('output#rngSatisfacao').textContent = document.getElementById('rngSatisfacao').value;
}

