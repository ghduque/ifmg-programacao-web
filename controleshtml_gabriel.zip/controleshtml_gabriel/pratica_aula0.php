<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <title>Tabela Periódica e Xadrez</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h2 {
            margin-top: 40px;
        }

        table {
            border-collapse: collapse;
            margin-bottom: 50px;
        }

        th,
        td {
            border: 1px solid #999;
            padding: 5px;
            text-align: center;
            width: 60px;
            height: 60px;
            font-size: 10px;
        }

        .metal {
            background-color: #b0e0e6;
        }

        .ametais {
            background-color: #98fb98;
        }

        .lantanideos {
            background-color: #ffc0cb;
        }

        .actinideos {
            background-color: #ffa07a;
        }

        /* Tabuleiro de xadrez */
        .chess-board td {
            width: 60px;
            height: 60px;
            font-size: 24px;
        }

        .white {
            background-color: #ffffff;
        }

        .blue {
            background-color: lightskyblue;
        }
    </style>
</head>

<body>
    <h2>Tabela Periódica</h2>
    <table>
        <!-- Linha 1 -->
        <tr>
            <td class="ametais">1<br>H<br>Hidrogênio</td>
            <td colspan="16"></td>
            <td class="ametais">2<br>He<br>Hélio</td>
        </tr>

        <!-- Linha 2 -->
        <tr>
            <td class="metal">3<br>Li<br>Lítio</td>
            <td class="metal">4<br>Be<br>Berílio</td>
            <td colspan="10"></td>
            <td class="ametais">5<br>B<br>Boro</td>
            <td class="ametais">6<br>C<br>Carbono</td>
            <td class="ametais">7<br>N<br>Nitrogênio</td>
            <td class="ametais">8<br>O<br>Oxigênio</td>
            <td class="ametais">9<br>F<br>Flúor</td>
            <td class="ametais">10<br>Ne<br>Neônio</td>
        </tr>

        <!-- Linha 3 -->
        <tr>
            <td class="metal">11<br>Na<br>Sódio</td>
            <td class="metal">12<br>Mg<br>Magnésio</td>
            <td colspan="10"></td>
            <td class="metal">13<br>Al<br>Alumínio</td>
            <td class="metal">14<br>Si<br>Silício</td>
            <td class="ametais">15<br>P<br>Fósforo</td>
            <td class="ametais">16<br>S<br>Enxofre</td>
            <td class="ametais">17<br>Cl<br>Cloro</td>
            <td class="ametais">18<br>Ar<br>Argônio</td>
        </tr>

        <!-- Linha 4 -->
        <tr>
            <td class="metal">19<br>K<br>Potássio</td>
            <td class="metal">20<br>Ca<br>Cálcio</td>
            <td class="metal">21<br>Sc<br>Escândio</td>
            <td class="metal">22<br>Ti<br>Titânio</td>
            <td class="metal">23<br>V<br>Vanádio</td>
            <td class="metal">24<br>Cr<br>Cromo</td>
            <td class="metal">25<br>Mn<br>Manganês</td>
            <td class="metal">26<br>Fe<br>Ferro</td>
            <td class="metal">27<br>Co<br>Cobalto</td>
            <td class="metal">28<br>Ni<br>Níquel</td>
            <td class="metal">29<br>Cu<br>Cobre</td>
            <td class="metal">30<br>Zn<br>Zinco</td>
            <td class="metal">31<br>Ga<br>Gálio</td>
            <td class="metal">32<br>Ge<br>Germânio</td>
            <td class="ametais">33<br>As<br>Arsênio</td>
            <td class="ametais">34<br>Se<br>Selênio</td>
            <td class="ametais">35<br>Br<br>Bromo</td>
            <td class="ametais">36<br>Kr<br>Xenônio</td>
        </tr>

        <!-- Linha 5 -->
        <tr>
            <td class="metal">37<br>Rb<br>Rubídio</td>
            <td class="metal">38<br>Sr<br>Estrôncio</td>
            <td class="metal">39<br>Y<br>Ítrio</td>
            <td class="metal">40<br>Zr<br>Zircônio</td>
            <td class="metal">41<br>Nb<br>Nióbio</td>
            <td class="metal">42<br>Mo<br>Molibdênio</td>
            <td class="metal">43<br>Tc<br>Tecnécio</td>
            <td class="metal">44<br>Ru<br>Rutênio</td>
            <td class="metal">45<br>Rh<br>Ródio</td>
            <td class="metal">46<br>Pd<br>Paládio</td>
            <td class="metal">47<br>Ag<br>Prata</td>
            <td class="metal">48<br>Cd<br>Cádmio</td>
            <td class="metal">49<br>In<br>Índio</td>
            <td class="metal">50<br>Sn<br>Estanho</td>
            <td class="ametais">51<br>Sb<br>Antimônio</td>
            <td class="ametais">52<br>Te<br>Telúrio</td>
            <td class="ametais">53<br>I<br>Iodo</td>
            <td class="ametais">54<br>Xe<br>Xenônio</td>
        </tr>

        <!-- Linha 6: Lantanídeos -->
        <tr>
            <td colspan="2"></td>
            <td class="lantanideos">57<br>La<br>Lantânio</td>
            <td class="lantanideos">58<br>Ce<br>Cério</td>
            <td class="lantanideos">59<br>Pr<br>Praseodímio</td>
            <td class="lantanideos">60<br>Nd<br>Neodímio</td>
            <td class="lantanideos">61<br>Pm<br>Promécio</td>
            <td class="lantanideos">62<br>Sm<br>Samário</td>
            <td class="lantanideos">63<br>Eu<br>Europio</td>
            <td class="lantanideos">64<br>Gd<br>Gadolínio</td>
            <td class="lantanideos">65<br>Tb<br>Térbio</td>
            <td class="lantanideos">66<br>Dy<br>Disprósio</td>
            <td class="lantanideos">67<br>Ho<br>Hólmio</td>
            <td class="lantanideos">68<br>Er<br>Érbio</td>
            <td class="lantanideos">69<br>Tm<br>Túlio</td>
            <td class="lantanideos">70<br>Yb<br>Itérbio</td>
            <td class="lantanideos">71<br>Lu<br>Lutécio</td>
            <td></td>
        </tr>

        <!-- Linha 7: Actinídeos -->
        <tr>
            <td colspan="2"></td>
            <td class="actinideos">89<br>Ac<br>Actínio</td>
            <td class="actinideos">90<br>Th<br>Tório</td>
            <td class="actinideos">91<br>Pa<br>Protactínio</td>
            <td class="actinideos">92<br>U<br>Urânio</td>
            <td class="actinideos">93<br>Np<br>Netúnio</td>
            <td class="actinideos">94<br>Pu<br>Plutônio</td>
            <td class="actinideos">95<br>Am<br>Amerício</td>
            <td class="actinideos">96<br>Cm<br>Cúrio</td>
            <td class="actinideos">97<br>Bk<br>Berkélio</td>
            <td class="actinideos">98<br>Cf<br>Califórnio</td>
            <td class="actinideos">99<br>Es<br>Einsteinio</td>
            <td class="actinideos">100<br>Fm<br>Férmio</td>
            <td class="actinideos">101<br>Md<br>Mendelévio</td>
            <td class="actinideos">102<br>No<br>Nobélio</td>
            <td class="actinideos">103<br>Lr<br>Lawrêncio</td>
            <td></td>
        </tr>

        <!-- Linha 8: Elementos 104 a 118 -->
        <tr>
            <td class="metal">104<br>Rf<br>Rutherfórdio</td>
            <td class="metal">105<br>Db<br>Dúbnio</td>
            <td class="metal">106<br>Sg<br>Seabórgio</td>
            <td class="metal">107<br>Bh<br>Bóhrio</td>
            <td class="metal">108<br>Hs<br>Hássio</td>
            <td class="metal">109<br>Mt<br>Meitnério</td>
            <td class="metal">110<br>Ds<br>Darmstádio</td>
            <td class="metal">111<br>Rg<br>Roentgênio</td>
            <td class="metal">112<br>Cn<br>Copernício</td>
            <td class="ametais">113<br>Nh<br>Nihônio</td>
            <td class="ametais">114<br>Fl<br>Fleróvio</td>
            <td class="ametais">115<br>Mc<br>Moscóvio</td>
            <td class="ametais">116<br>Lv<br>Livermório</td>
            <td class="ametais">117<br>Ts<br>Tennessino</td>
            <td class="ametais">118<br>Og<br>Oganessônio</td>
            <td colspan="3"></td>
        </tr>
    </table>

    <h2>Tabuleiro de Xadrez</h2>
    <table class="chess-board">
        <!-- Linha 1 -->
        <tr>
            <td class="blue">&#9820;</td>
            <td class="white">&#9822;</td>
            <td class="blue">&#9821;</td>
            <td class="white">&#9819;</td>
            <td class="blue">&#9818;</td>
            <td class="white">&#9821;</td>
            <td class="blue">&#9822;</td>
            <td class="white">&#9820;</td>
        </tr>
        <!-- Linha 2 -->
        <tr>
            <td class="white">&#9823;</td>
            <td class="blue">&#9823;</td>
            <td class="white">&#9823;</td>
            <td class="blue">&#9823;</td>
            <td class="white">&#9823;</td>
            <td class="blue">&#9823;</td>
            <td class="white">&#9823;</td>
            <td class="blue">&#9823;</td>
        </tr>
        <!-- Linha 3 -->
        <tr>
            <td class="blue"></td>
            <td class="white"></td>
            <td class="blue"></td>
            <td class="white"></td>
            <td class="blue"></td>
            <td class="white"></td>
            <td class="blue"></td>
            <td class="white"></td>
        </tr>
        <!-- Linha 4 -->
        <tr>
            <td class="white"></td>
            <td class="blue"></td>
            <td class="white"></td>
            <td class="blue"></td>
            <td class="white"></td>
            <td class="blue"></td>
            <td class="white"></td>
            <td class="blue"></td>
        </tr>
        <!-- Linha 5 -->
        <tr>
            <td class="blue"></td>
            <td class="white"></td>
            <td class="blue"></td>
            <td class="white"></td>
            <td class="blue"></td>
            <td class="white"></td>
            <td class="blue"></td>
            <td class="white"></td>
        </tr>
        <!-- Linha 6 -->
        <tr>
            <td class="white"></td>
            <td class="blue"></td>
            <td class="white"></td>
            <td class="blue"></td>
            <td class="white"></td>
            <td class="blue"></td>
            <td class="white"></td>
            <td class="blue"></td>
        </tr>
        <!-- Linha 7 -->
        <tr>
            <td class="blue">&#9817;</td>
            <td class="white">&#9817;</td>
            <td class="blue">&#9817;</td>
            <td class="white">&#9817;</td>
            <td class="blue">&#9817;</td>
            <td class="white">&#9817;</td>
            <td class="blue">&#9817;</td>
            <td class="white">&#9817;</td>
        </tr>
        <!-- Linha 8 -->
        <tr>
            <td class="white">&#9814;</td>
            <td class="blue">&#9816;</td>
            <td class="white">&#9815;</td>
            <td class="blue">&#9813;</td>
            <td class="white">&#9812;</td>
            <td class="blue">&#9815;</td>
            <td class="white">&#9816;</td>
            <td class="blue">&#9814;</td>
        </tr>
    </table>

</body>

</html>
