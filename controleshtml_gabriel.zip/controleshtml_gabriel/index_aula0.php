<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0 ">
    <title>Aula 1 - Controles HTML</title>
    <!--CSS -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    Exercício 1
    <table border="1px" width="60%" height="150px">
        <tr align="center" height="40px"">
        <th width=" 10%">
            ID
            </th>
            <th width="10%">
                Nome
            </th>
            <th width="10%">
                Idade
            </th>
        </tr>
        <tr align="center">
            <td>
                1
            </td>
            <td>
                Gabriel
            </td>
            <td>
                25
            </td>
        </tr>
        <tr align="center">
            <td>
                2
            </td>
            <td>
                João
            </td>
            <td>
                30
            </td>
        </tr>
        <tr align="center">
            <td colspan="3">Solitária</td>>
        </tr>

        <tr>
            <td align="center">3</td>
            <td>Pedro</td>
            <td>28</td>
        </tr>
        <tr>
            <td align="center">4</td>
            <td>Lucas</td>
            <td>22</td>
        </tr>
    </table>

    Exercício 2

    <table border="1px">
        <tr>
            <td align="center" colspan="3">A</td>
        </tr>
        <tr>
            <td>
                B
            </td>
            <td>
                C
            </td>
            <td>
                D
            </td>
        </tr>
        <tr>
            <td align="center" rowspan="2" colspan="2">E</td>
            <td>F</td>
        </tr>
        <tr>
            <td>G</td>
        </tr>
        </tr>
        <tr>
            <td>H</td>
            <td align="center" rowspan="2" colspan="2">J</td>
        </tr>
        <tr>
            <td>I</td>
        </tr>
    </table>
    <!-- js -->
    <script src="js/script.js"></script>
    Exercício 3
    <table border="1px" width="800px" height="1000px">
        <tr align="center" height="20%" width="800px">
            <th colspan="2">
                Banner
            </th>
        </tr>
        <tr height="70%">
            <td align="center" width="20%">
                Menu
            </td>
            <td align="center" width="80%">
                Conteudo
            </td>
        </tr>
        <tr>
            <td colspan="4" align="center" width="10%">
                Rodape
            </td>
        </tr>
    </table>
    Prática 1
    <table  width="100%" height="1000px" style="border-collapse: collapse; border: none;">
        <tr>
            <td align="center" width="10%" style="background-color: khaki;">
                Espaço 1
            </td>
            <td align="center" width="1%" height="1000px"
                style="background: linear-gradient(90deg,rgba(240, 230, 140, 1) 0%, rgba(255, 250, 205, 1) 50%, rgba(0, 0, 0, 1) 100%);">
            <td width="0.01%">
                <table width="800px" height="1000px" style="background-color: white;" style="border-collapse: collapse; border: none;">
                    <tr align="center" height="20%" width="800px" style="background-color: LightGoldenRodYellow ;">
                        <th colspan="2">
                            Banner
                            <img src="img/banana.jpg" alt="Uma imagem" width="800" height="170">
                        </th>
                    </tr>
                    <tr height="70%">
                        <td align="center" width="20%" style="background-color: Khaki;">
                            Menu
                        </td>
                        <td align="center" width="80%" style="background-color: LightYellow;">
                            Macaco Musical 
                            <img src="img/monkey.gif" alt="Uma imagem" width="650" height="600">
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4" align="center" width="10%" style="background-color: PaleGoldenRod ;">
                            Rodape
                        </td>
                    </tr>
                </table>
            </td>
            </td>
            <td align="center" width="1%" height="1000px"
                style="background: linear-gradient(to left,rgba(240, 230, 140, 1) 0%, rgba(255, 250, 205, 1) 50%, rgba(0, 0, 0, 1) 100%);">
            </td>
            <td align="center" width="10%" style="background-color: khaki;">
                Espaço 2
            </td>
            </td>
        </tr>
    </table>

</body>

</html>