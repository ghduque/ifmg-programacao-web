<!DOCTYPE html>
<html lang="pt-br">
<!-- AULA 0 - DEMONSTRAÇÃO DE CONTROLES -->

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0 ">
    <!--CSS -->
    <title>Formul&aacute;rio HTML - DEMONSTRA&Ccedil;&Atilde;O DE CONTROLES</title>
    <link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>

<body>
    <h1>
        Demonstra&ccedil;&atilde;o de Controles HTML para Formul&aacute;rios
    </h1>
    <!-- formulário principal com enctype para upload de arquivos--->
    <form name="frmCadastro" id="frmCadastro" action="processa.php" method="post" enctype="multipart/form-data">

        <!-- campo oculto - armazena dados que não devem ser exibidos ao usuário -->
        <input 
            type="hidden" 
            name="txtId" 
            id="txtId" 
            value="ABC123XYZ"
        />

        <table border="1px">
            <tr>
                <td class="secao-titulo" colspan="2">
                    <h2>Formul&aacute;rio de Cadastro Completo</h2>
                </td> 
            </tr>

            <!--- titulo principal do formulário --->
            <tr>
                <td colspan="2" class="subsecao-titulo">
                    <h2>Campos de textos B&aacute;sicos</h2>
                </td>
            </tr>

            <tr>
                <td width="30%">C&oacute;digo do Cliente</td>

                <td>
                    <input 
                    type="text" 
                    name="txtCodigo" 
                    value="CLI-2025-001" 
                    readonly="readonly">
                    <small class="tip">
                        (Campo somente leitura)
                    </small>
                </td>
            </tr>

            <!--- campo texto simples --->
            <tr>
                <td>Nome Completo</td>
                <td>
                    <input 
                         type="text" 
                         name="txtNome" 
                         id="txtNome" 
                         placeholder="Digite o nome completo"
                         maxlength="100"
                         size="45" 
                         required 
                    />
                    <small>(Máximo 100 caracteres)</small>
                </td>
            </tr>

            <!--- input password - campo de senha com caracteres ocultos  --->
            <tr>
                <td>Senha</td>
                <td>
                    <input 
                          type="password" 
                          name="txtSenha" 
                          id="txtSenha" 
                          placeholder="Digite a senha de acesso"
                          minlength="6" 
                          maxlength="20" 
                          size="20" 
                          value="123456" 
                          required 
                    />
                    <small>(Entre 6 a 20 caracteres)</small>
                </td>

                <!--- campo desabilitado (exemplo) --->
            <tr>
                <td>Campo Desabilitado</td>
                <td>
                    <input 
                          type="text" 
                          name="txtDesabilitado" 
                          id="txtDesabilitado" 
                          value="Este Campo está Desabilitado"
                          disabled="disabled" 
                          size="25"
                     />
                    <small>(Não ser&aacute; enviado)</small>
                </td>
            </tr>

            <!---secao: campos html5 de validacao--->
            <tr>
                <td colspan="2" class="subsecao-titulo">
                    <h2>Campos HTML5 de Valida&ccedil;&atilde;o Autom&aacute;tico</h2>
                </td>
            </tr>

            <!--- input email - validacao automatica formato de email --->
            <tr>
                <td>E-mail:</td>
                <td>
                    <input 
                    type="email" 
                    name="txtEmail" 
                    id="txtEmail" 
                    placeholder="usuario@exemplo.com" 
                    required
                     />
                    <small>(Valida&ccedil;&atilde;o Autom&aacute;tica de email)</small>
                </td>
            </tr>

            <!-- botão para enviar formulário -->
            <tr>
                <td colspan="2" align="right">
                    <input 
                    type="submit" 
                    value="Enviar Formul&aacute;rio" 
                    name="btnEnviar" 
                    id="btnEnviar" />
                </td>
            </tr>

            <!--- input url - validacao automatica de formato de url--->
            <tr>
                <td>Website</td>
                <td>
                    <input 
                    type="url" 
                    name="txtWebsite" 
                    id="txtWebsite" 
                    placeholder="https://www.teste.com" 
                    required 
                    />
                    <small>(Deve iniciar com http:// ou https://)</small>
                </td>

            <!--- input telefone - validacao automatica de formato de telefone---> 
            </tr>
            <td>Telefone</td>
            <td>
                <input type="tel" 
                       name="txtTelefone" 
                       id="txtTelefone" 
                       required 
                       placeholder="(11) 98765-4321"
                       pattern="\([0-9]{2}\) [0-9]{5}-[0-9]{4}" />
                <small>Formato: (99) 99999-9999</small>
            </td>
            </tr>

            <!--- input cpf - validacao automatica de formato de cpf--->
            <tr>
                <td>CPF</td>
                <td>
                    <input
                    type="text"
                    name="txtCpf"
                    id="txtCpf"
                    required
                    placeholder="Insira seu CPF"
                    pattern="\d{3}\.\d{3}\.\d{3}-\d{2}"
                    />
                    <small>Formato: '111.111.111-11'</small>

        <!--- input search - campo otimizado para busca ---> 
        <tr>
            <td>Buscar Produto:</td>
                <td>
                    <input 
                    type="search"
                    name="txtBusca"
                    id="txtBusca"
                    placeholder="Digite o nome do Produto"
                    size="38"
                    requires
                    />
                    <small>(Campo com botao X para limpar)</small>
                </td>
        </tr>
    <tr> 
        <td colspan="2" class="subsecao-titulo">
            <h2>Campos Num&eacute;ricos e de Intervalo</h2>
        </td>
    </tr>
<table border="1px">
   <!---input number- campo numerico com setas de incremento--->
 <tr>
 <td>Idade:</td>
 <td>
 <input
type="number"
name="txtIdade"
id="txtIdade"
min="1"
max="120"
step="1"
value="25"
oninput="atualizaOutIdade()"
 />
 <output id="txtIdade">25 </output> anos
 <small class="tip">(Use as setas ou Digite!)</small>
 </td>
 </tr>
<!---input range- controle deslizante para selecao de valor--->
 <tr>
 <td>N&iacute;vel de Satisfação</td>
 <td>
 <input
type="range"
name="rngSatisfacao"
id="rngSatisfacao"
min="0"
max="10"
value="5"
oninput="atualizaOutSatisfacao()"
 />
 Nota: <output id="rngSatisfacao">5</output>/10
 <small>(Arraste o controle)</small>
 </td>
 </tr>

 <tr>
    <td colspan="2" class="subsecao-titulo" text="align center">
      <h2>Campos de Data e Hora<h2>
    </td>
 </tr>

 <!---input date - seletor de data --->
 <tr>
    <td>
        Data de Nascimento
    </td>
    <td>
       <input
            type="date"
            name="txtDataNascimento"
            min="1900-01-01"
            max="2025-10-01"
            />
            <small>(Formato: dd/mm/aaaa)</small>
    </td>
 </tr>

 <!---input date - seletor de horario --->
 <tr>
    <td>
        Horario Preferencial 
    </td>
    <td>
       <input
            type="time"
            name="tmHorario"
            />
            <small>(Formato: hh:mm)</small>
    </td>
 </tr>

  <!---input date - seletor de data e hora combinados --->
 <tr>
    <td>
        Data e Hora do Agendamento
    </td>
    <td>
       <input
            type="datetime-local"
            name="txtAgendamento"
            />
            <small>(Data e Hora Local)</small>
    </td>
 </tr>

  <!---input date - seletor de mes e ano --->
 <tr>
    <td>
       Mes de Referencia
    </td>
    <td>
       <input
            type="month"
            name="txtMes"
            />
            <small>(Selecione o Mes e o Ano)</small>
    </td>
 </tr>

  <!---input date - seletor de semana --->
 <tr>
    <td>
        Semana de Ferias
    </td>
    <td>
       <input
            type="week"
            name="txtSemana"
            />
            <small>(Selecione a semana do ano)</small>
    </td>
 </tr>

 <!---input - campos de selecao--->
<tr>
    <td colspan="2" class="subsecao-titulo">
        Campos de Seleção e Escolha
    </td>
</tr>

 <!---input date - seletor de cor --->
 <tr>
    <td>
        Cor Preferida
    </td>
    <td>
       <input
            type="color"
            name="txtCor"
            value="#4CAF50"
            />
            <small>(Clique para escolher uma cor)</small>
    </td>
 </tr>

  <!---input date - upload de imagem --->
 <tr>
    <td>
        Foto de Perfil
    </td>
    <td>
       <input
            type="file"
            name="fleFoto"
            accept="image/*"
            />
            <small>(Apenas Imagens)</small>
    </td>
 </tr>

 </table>




      </table>
    </form>
    <!-- scripts -->
    <script src="js/script.js"></script>
</body>

</html>
