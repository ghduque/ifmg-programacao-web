<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Equalizador DJ</title>

    <style>
        /* ============================================
           EQUALIZADOR DJ - CSS
           ============================================ */

        /* Container da tabela do equalizador */
        table.equalizador-dj {
            background: linear-gradient(145deg, rgba(20, 20, 20, 0.95), rgba(10, 10, 10, 0.98)) !important;
            border-radius: 30px !important;
            padding: 20px !important;
            box-shadow: 
                0 30px 80px rgba(0, 0, 0, 0.8),
                0 0 0 1px rgba(255, 255, 255, 0.1),
                inset 0 1px 0 rgba(255, 255, 255, 0.1) !important;
            border: none !important;
            margin: 40px auto !important;
            min-width: 500px; /* Largura mínima para acomodar o layout */
            font-family: Arial, sans-serif;
        }

        /* Células e Linhas */
        table.equalizador-dj tr {
            border: none !important;
        }
        table.equalizador-dj td {
            border: none !important;
            background: transparent !important;
            color: rgba(255, 255, 255, 0.8) !important;
            padding: 10px !important;
            vertical-align: middle; /* Alinha verticalmente o conteúdo da célula */
        }

        /* Título principal DJ */
        table.equalizador-dj .secao-titulo {
            background: linear-gradient(90deg, #00ffff, #ff00ff, #ffff00, #00ffff) !important;
            background-size: 200% auto !important;
            -webkit-background-clip: text !important;
            background-clip: text !important;
            -webkit-text-fill-color: transparent !important;
            font-size: 2em !important;
            animation: gradientText 3s linear infinite !important;
            filter: drop-shadow(0 0 20px rgba(0, 255, 255, 0.5)) !important;
            padding: 10px !important;
            text-align: center; /* Garantir centralização */
        }
        @keyframes gradientText {
            0% { background-position: 0% center; }
            100% { background-position: 200% center; }
        }

        /* Regulador Geral */
        .regulador-geral-container {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
            padding: 10px;
        }
        .regulador-geral-label {
            color: #ffd700 !important;
            text-shadow: 0 0 15px rgba(255, 215, 0, 0.6) !important;
            font-weight: bold;
            font-size: 1.1em;
        }

        /* Estrutura das linhas de cada controle Fader */
        .equalizador-dj .fader-label {
            font-weight: bold;
            text-transform: uppercase;
            text-align: right;
            width: 180px; /* Define uma largura fixa para alinhar os sliders */
            padding-right: 15px;
        }

        .equalizador-dj .fader-value {
            color: rgba(255, 255, 255, 0.8);
            font-size: 0.9em;
            margin-top: 5px;
        }

        /* Cores dos Rótulos (Labels) */
        table.equalizador-dj tr:nth-child(3) .fader-label { color: #ff0080; text-shadow: 0 0 15px #ff0080; } /* Agudo */
        table.equalizador-dj tr:nth-child(4) .fader-label { color: #ff00ff; text-shadow: 0 0 15px #ff00ff; } /* Agudo Médio */
        table.equalizador-dj tr:nth-child(5) .fader-label { color: #00ffff; text-shadow: 0 0 15px #00ffff; } /* Médio */
        table.equalizador-dj tr:nth-child(6) .fader-label { color: #00ff00; text-shadow: 0 0 15px #00ff00; } /* Médio Grave */
        table.equalizador-dj tr:nth-child(7) .fader-label { color: #ffff00; text-shadow: 0 0 15px #ffff00; } /* Grave */

        /* Caixas de valor (minimalistas) */
        table.equalizador-dj output {
            font-size: 1.1em !important;
            font-weight: bold !important;
            text-shadow: 0 0 8px currentColor !important;
            padding: 4px 10px !important;
            background: rgba(0, 0, 0, 0.4) !important;
            border-radius: 8px !important;
            border: 1px solid currentColor !important;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5) !important;
            display: inline-block !important;
            min-width: 35px !important;
            text-align: center !important;
        }
        #outEqualizadorGeral { font-size: 1.3em !important; color: #ffd700; border-color: #ffd700; }
        #outEqualizadorAgudo { color: #ff0080 !important; }
        #outEqualizadorAgudoMedio { color: #ff00ff !important; }
        #outEqualizadorMedio { color: #00ffff !important; }
        #outEqualizadorMedioGrave { color: #00ff00 !important; }
        #outEqualizadorGrave { color: #ffff00 !important; }

        /* Reset de aparência para todos os sliders */
        table.equalizador-dj input[type="range"] {
            -webkit-appearance: none; appearance: none; background: transparent; cursor: pointer;
        }

        /* Slider Geral (Horizontal) */
        #rngEqualizadorGeral {
            background: linear-gradient(to right, #ff0080, #ff00ff, #00ffff, #00ff00, #ffff00) !important;
            height: 12px !important; width: 300px !important; border-radius: 6px;
        }
        #rngEqualizadorGeral::-webkit-slider-thumb {
            -webkit-appearance: none; width: 30px; height: 30px;
            background: radial-gradient(circle, #ffffff, #ffd700); border-radius: 50%;
            box-shadow: 0 0 20px rgba(255, 215, 0, 0.8); border: 3px solid #fff;
            cursor: pointer; transition: transform 0.2s; margin-top: -9px; /* Ajuste vertical */
        }
        #rngEqualizadorGeral::-webkit-slider-thumb:hover { transform: scale(1.2); }
        
        /* Estilo comum para os 5 faders */
        .equalizador-dj input[type="range"]:not(#rngEqualizadorGeral) {
            width: 60%; /* Ocupa o espaço disponível na célula */
            height: 8px;
            background: #333;
            border-radius: 4px;
            border: 1px solid #555;
        }

        .equalizador-dj input[type="range"]:not(#rngEqualizadorGeral)::-webkit-slider-thumb {
            -webkit-appearance: none;
            width: 20px;
            height: 20px;
            background: radial-gradient(circle, #ffffff, currentColor); /* Usa a cor do slider */
            cursor: grab;
            border-radius: 50%;
            border: 3px solid #fff;
            box-shadow: 0 0 15px currentColor, 0 3px 10px rgba(0, 0, 0, 0.5);
            transition: all 0.2s;
            margin-top: -7px; /* Centraliza o thumb na barra */
        }

        .equalizador-dj input[type="range"]:not(#rngEqualizadorGeral)::-webkit-slider-thumb:hover {
            transform: scale(1.1);
        }

        /* Define a cor de cada fader, que será usada pelo thumb via 'currentColor' */
        #rngEqualizadorAgudo { color: #ff0080; }
        #rngEqualizadorAgudoMedio { color: #ff00ff; }
        #rngEqualizadorMedio { color: #00ffff; }
        #rngEqualizadorMedioGrave { color: #00ff00; }
        #rngEqualizadorGrave { color: #ffff00; }
    </style>
</head>
<body style="background-color: #000; margin: 0; padding: 0;">

    <table class="equalizador-dj">
        <tbody>
            <tr>
                <td align="center" colspan="2" class="secao-titulo">🎧 Equalizador DJ 🎧</td>
            </tr>

            <tr>
                <td align="center" colspan="2">
                    <div class="regulador-geral-container">
                        <span class="regulador-geral-label">⚡ Regulador Geral ⚡</span>
                        <input type="range" name="rngEqualizador" id="rngEqualizadorGeral" min="1" max="5" value="3" oninput="atualizaEqualizador()">
                        <div class="regulador-geral-valor">
                            <span style="color:white">Valor:</span> <output id="outEqualizadorGeral">3</output>
                        </div>
                    </div>
                </td>
            </tr>

            <tr>
                <td class="fader-label">Agudo 🔥</td>
                <td>
                    <input type="range" name="rngEqualizadorAgudo" id="rngEqualizadorAgudo" min="1" max="5" value="1" oninput="atualizaValorOutput('rngEqualizadorAgudo', 'outEqualizadorAgudo')">
                    <div class="fader-value">
                        Valor: <output id="outEqualizadorAgudo">1</output>/5
                    </div>
                </td>
            </tr>

            <tr>
                <td class="fader-label">Agudo Médio 💜</td>
                <td>
                    <input type="range" name="rngEqualizadorAgudoMedio" id="rngEqualizadorAgudoMedio" min="1" max="5" value="1" oninput="atualizaValorOutput('rngEqualizadorAgudoMedio', 'outEqualizadorAgudoMedio')">
                    <div class="fader-value">
                        Valor: <output id="outEqualizadorAgudoMedio">1</output>/5
                    </div>
                </td>
            </tr>

            <tr>
                <td class="fader-label">Médio 💎</td>
                <td>
                    <input type="range" name="rngEqualizadorMedio" id="rngEqualizadorMedio" min="1" max="5" value="5" oninput="atualizaValorOutput('rngEqualizadorMedio', 'outEqualizadorMedio')">
                    <div class="fader-value">
                        Valor: <output id="outEqualizadorMedio">5</output>/5
                    </div>
                </td>
            </tr>

            <tr>
                <td class="fader-label">Médio Grave #</td>
                <td>
                    <input type="range" name="rngEqualizadorMedioGrave" id="rngEqualizadorMedioGrave" min="1" max="5" value="1" oninput="atualizaValorOutput('rngEqualizadorMedioGrave', 'outEqualizadorMedioGrave')">
                    <div class="fader-value">
                        Valor: <output id="outEqualizadorMedioGrave">1</output>/5
                    </div>
                </td>
            </tr>

            <tr>
                <td class="fader-label">Grave ⚡</td>
                <td>
                    <input type="range" name="rngEqualizadorGrave" id="rngEqualizadorGrave" min="1" max="5" value="1" oninput="atualizaValorOutput('rngEqualizadorGrave', 'outEqualizadorGrave')">
                    <div class="fader-value">
                        Valor: <output id="outEqualizadorGrave">1</output>/5
                    </div>
                </td>
            </tr>
        </tbody>
    </table>

    <script>
        // ============================================
        // EQUALIZADOR DJ PSICODÉLICO - JAVASCRIPT
        // ============================================

        function atualizaEqualizador() {
            var tipo = document.getElementById('rngEqualizadorGeral').value;
            
            // Atualiza o output do regulador geral
            document.getElementById('outEqualizadorGeral').textContent = tipo;
            
            switch (tipo) {
                case '1': // Destaca o Agudo
                    setarValor('rngEqualizadorAgudo', 5);
                    setarValor('rngEqualizadorAgudoMedio', 1);
                    setarValor('rngEqualizadorMedio', 1);
                    setarValor('rngEqualizadorMedioGrave', 1);
                    setarValor('rngEqualizadorGrave', 1);
                    break;
                    
                case '2': // Destaca o Agudo Médio
                    setarValor('rngEqualizadorAgudo', 1);
                    setarValor('rngEqualizadorAgudoMedio', 5);
                    setarValor('rngEqualizadorMedio', 1);
                    setarValor('rngEqualizadorMedioGrave', 1);
                    setarValor('rngEqualizadorGrave', 1);
                    break;
                    
                case '3': // Destaca o Médio
                    setarValor('rngEqualizadorAgudo', 1);
                    setarValor('rngEqualizadorAgudoMedio', 1);
                    setarValor('rngEqualizadorMedio', 5);
                    setarValor('rngEqualizadorMedioGrave', 1);
                    setarValor('rngEqualizadorGrave', 1);
                    break;
                    
                case '4': // Destaca o Médio Grave
                    setarValor('rngEqualizadorAgudo', 1);
                    setarValor('rngEqualizadorAgudoMedio', 1);
                    setarValor('rngEqualizadorMedio', 1);
                    setarValor('rngEqualizadorMedioGrave', 5);
                    setarValor('rngEqualizadorGrave', 1);
                    break;
                    
                case '5': // Destaca o Grave
                    setarValor('rngEqualizadorAgudo', 1);
                    setarValor('rngEqualizadorAgudoMedio', 1);
                    setarValor('rngEqualizadorMedio', 1);
                    setarValor('rngEqualizadorMedioGrave', 1);
                    setarValor('rngEqualizadorGrave', 5);
                    break;
            }
        }

        function setarValor(id, valor) {
            // Atualiza o valor do input range
            var input = document.getElementById(id);
            if (input) {
                input.value = valor;
            }
            
            // Atualiza o output correspondente
            var outputId = id.replace('rng', 'out');
            var output = document.getElementById(outputId);
            if (output) {
                output.textContent = valor;
            }
        }

        function atualizaValorOutput(idInput, idOutput) {
            var valor = document.getElementById(idInput).value;
            document.getElementById(idOutput).textContent = valor;
        }
    </script>
</body>
</html>